#include "BluetoothSerial.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// #define USE_NAME // Comment this to use MAC address instead of slaveName
const char *pin = "1234";  // Change this to reflect the pin expected by the real slave BT device

#if !defined(CONFIG_BT_SPP_ENABLED)
#error Serial Bluetooth not available or not enabled. It is only available for the ESP32 chip.
#endif


BluetoothSerial SerialBT;

#ifdef USE_NAME
String slaveName = "HC-05";  // Change this to reflect the real name of your slave BT device
#else
String MACadd = "AA:BB:CC:11:22:33";                          // This only for printing
uint8_t address[6] = { 0x00, 0x22, 0x03, 0x01, 0x00, 0xe7 };  // Change this to reflect real MAC address of your slave BT device
#endif

String myName = "ESP32-BT-Master";

// Vibration sensor and button pin
const int vibrationPin = 2;  // D2
const int buttonPin = 12;    // D12

#define buz 23
volatile bool vibrationDetected = false;

void IRAM_ATTR vibrationISR() {
  vibrationDetected = true;
}

void setup() {
  Serial.begin(115200);

  // Initialize Bluetooth serial communication
  SerialBT.begin(myName, true);
  Serial.printf("The device \"%s\" started in master mode, make sure slave BT device is on!\n", myName.c_str());

#ifndef USE_NAME
  SerialBT.setPin(pin);
  Serial.println("Using PIN");
#endif

  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;)
      ;  // Don't proceed, loop forever
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.display();
  delay(2000);

  display.clearDisplay();
  display.setTextSize(1);

  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(25, 0);
  display.print(F("SH-AID"));
  display.setTextSize(1);
  display.setCursor(0, 13);
  display.print(F("---------------------"));

  display.display();

  // Attach interrupt to the vibration sensor
  pinMode(vibrationPin, INPUT);
  pinMode(buz, OUTPUT);

  digitalWrite(buz, LOW);
  attachInterrupt(digitalPinToInterrupt(vibrationPin), vibrationISR, RISING);

  // Attach button pin
  pinMode(buttonPin, INPUT_PULLUP);

  // Start Bluetooth task
  xTaskCreatePinnedToCore(bluetoothTask, "BluetoothTask", 4096, NULL, 1, NULL, 1);

  // Start vibration sensor task
  xTaskCreatePinnedToCore(vibrationTask, "VibrationTask", 4096, NULL, 1, NULL, 1);

  // Start button press task
  xTaskCreatePinnedToCore(buttonTask, "ButtonTask", 4096, NULL, 1, NULL, 1);

  // Start the reconnection task
  xTaskCreatePinnedToCore(reconnectBluetoothTask, "ReconnectBluetoothTask", 4096, NULL, 1, NULL, 1);
}

void bluetoothTask(void *pvParameters) {
  bool connected = false;
#ifdef USE_NAME
  connected = SerialBT.connect(slaveName);
  Serial.printf("Connecting to slave BT device named \"%s\"\n", slaveName.c_str());
#else
  connected = SerialBT.connect(address);
  Serial.print("Connecting to slave BT device with MAC ");
  Serial.println(MACadd);
#endif

  if (connected) {
    Serial.println("Connected Successfully!");
    updateDisplay("Bluetooth Connected", 0);
  } else {
    Serial.println("Failed to connect. Reconnecting...");
    updateDisplay("Bluetooth Failed", 0);
  }

  // Main Bluetooth communication loop
  while (1) {
    if (Serial.available()) {
      SerialBT.write(Serial.read());
    }
    if (SerialBT.available()) {
      Serial.write(SerialBT.read());
    }
    vTaskDelay(20 / portTICK_PERIOD_MS);  // 20 ms delay
  }
}

void vibrationTask(void *pvParameters) {
  while (1) {
    if (vibrationDetected) {
      SerialBT.println(11);       // Send 1 when vibration is detected
      vibrationDetected = false;  // Reset vibration detection flag
      updateDisplay("Vibration Detected!", 1);
      digitalWrite(buz, HIGH);
    }
    vTaskDelay(100 / portTICK_PERIOD_MS);  // Delay to reduce the frequency of checking
  }
}

void buttonTask(void *pvParameters) {
  while (1) {
    if (digitalRead(buttonPin) == LOW) {
      SerialBT.println(22);  // Send key 2 when button is pressed
      updateDisplay("Button Pressed", 1);
      delay(200);  // Debounce delay
      digitalWrite(buz, LOW);
    }
    vTaskDelay(50 / portTICK_PERIOD_MS);  // Delay for button checking
  }
}

void reconnectBluetoothTask(void *pvParameters) {
  while (1) {
    if (!SerialBT.connected()) {
      Serial.println("Bluetooth not connected. Reconnecting...");
      bool connected = false;
#ifdef USE_NAME
      connected = SerialBT.connect(slaveName);
      Serial.printf("Reconnecting to slave BT device named \"%s\"\n", slaveName.c_str());
#else
      connected = SerialBT.connect(address);
      Serial.print("Reconnecting to slave BT device with MAC ");
      Serial.println(MACadd);
#endif

      if (connected) {
        Serial.println("Reconnected Successfully!");
        updateDisplay("Reconnected", 0);
      } else {
        Serial.println("Failed to reconnect. Trying again...");
        updateDisplay("Reconnect Failed", 0);
      }
    }
    vTaskDelay(5000 / portTICK_PERIOD_MS);  // Delay before next check (5 seconds)
  }
}

// Helper function to update the display
void updateDisplay(const char *message, int line) {
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(25, 0);
  display.print(F("SH-AID"));
  display.setTextSize(1);
  display.setCursor(0, 13);
  display.print(F("---------------------"));
  display.setCursor(0, 30);
  display.print(message);

  display.display();
}

void loop() {
  // Nothing to do in loop, tasks are running independently
}
