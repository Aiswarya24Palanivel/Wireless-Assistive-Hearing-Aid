#include "FS.h"
#include "SD.h"
#include "SPI.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <HardwareSerial.h>
#include <WiFi.h>
#include <Wire.h>

#define RX_PIN 16
#define TX_PIN 17
HardwareSerial ble_soft(2);

// #define ble_soft Serial2
String receivedData = "";
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

#include <Audio.h> // needed for PLAYING Audio (via I2S Amplifier, e.g. MAX98357) with ..
// Audio.h library from Schreibfaul1: https://github.com/schreibfaul1/ESP32-audioI2S
// .. ensure you have actual version (July 18, 2024 or newer needed for 8bit wav files!)
#define AUDIO_FILE "/Audio.wav" // mandatory, filename for the AUDIO recording

// --- PRIVATE credentials -----
const char* ssid = "Project"; // ## INSERT your wlan ssid
const char* password = "1234567890"; // ## INSERT your password

// --- PIN assignments ---------
#define pin_RECORD_BTN 12
#define LED 2

#define vib_mot 26

// --- global Objects ----------
Audio audio_play;

#include "driver/i2s_std.h" // instead of older legacy #include <driver/i2s.h>
/* #include <SD.h>              // also needed, but already included in Main.ino */

// --- defines & macros --------

#ifndef DEBUG // user can define favorite behaviour ('true' displays addition info)
#define DEBUG true // <- define your preference here
#define DebugPrint(x)                                                                                                  \
    ;                                                                                                                  \
    if (DEBUG) {                                                                                                       \
        Serial.print(x);                                                                                               \
    } /* do not touch */
#define DebugPrintln(x)                                                                                                \
    ;                                                                                                                  \
    if (DEBUG) {                                                                                                       \
        Serial.println(x);                                                                                             \
    } /* do not touch */
#endif

// --- PIN assignments ---------

#define I2S_WS 25
#define I2S_SD 33
#define I2S_SCK 32

// --- define your settings ----

#define SAMPLE_RATE                                                                                                    \
    16000 // typical values: 8000 .. 44100, use e.g 8K (and 8 bit mono) for smallest .wav files \
                           // hint: best quality with 16000 or 24000 (above 24000: random dropouts and distortions) \
                           // recommendation in case the STT service produces lot of wrong words: try 16000

#define BITS_PER_SAMPLE                                                                                                \
    8 // 16 bit and 8bit supported (24 or 32 bits not supported) \
                           // hint: 8bit is less critical for STT services than a low 8kHz sample rate \
                           // for fastest STT: combine 8kHz and 8 bit.

#define GAIN_BOOSTER_I2S                                                                                               \
   25 // original I2S streams is VERY silent, so we added an optional GAIN booster for INMP441 \
                             // multiplier, values: 1-64 (32 seems best value for INMP441) \
                             // 64: high background noise but working well for STT on quiet human conversations

/*// Links of interest:
// SD Card Arduino library info: https://www.arduino.cc/reference/en/libraries/sd/
// SD Card ESP details: https://randomnerdtutorials.com/esp32-microsd-card-arduino/
// Dronebot I2S workshop: https://dronebotworkshop.com/esp32-i2s/ (using old I2S.h)
// Link WAV header: http://soundfile.sapp.org/doc/WaveFormat/
// Using tabs to organize code with the Arduino IDE: https://www.youtube.com/watch?v=HtYlQXt14zU */

// Code below is mainly based on Espressif API I2S Reference Doc (Latest Master, 3.0.1, June 2024)
// link: https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/peripherals/i2s.html#introduction
// snippets here: https://github.com/espressif/esp-adf/issues/1047

// --- global vars -------------

// [std_cfg]: KALO I2S_std configuration for I2S Input device (Microphone INMP441), detailed definitions (without
// macros) Details see: 'i2s_std.h'

i2s_std_config_t std_cfg = {
  .clk_cfg =  // instead of macro 'I2S_STD_CLK_DEFAULT_CONFIG(SAMPLE_RATE),'
  {
    .sample_rate_hz = SAMPLE_RATE,
    .clk_src = I2S_CLK_SRC_DEFAULT,
    .mclk_multiple = I2S_MCLK_MULTIPLE_256,
  },
  .slot_cfg =  // instead of macro I2S_STD_MSB_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO),
  {
    // hint: always using _16BIT because I2S uses 16 bit slots anyhow (even in case I2S_DATA_BIT_WIDTH_8BIT used !)
    .data_bit_width = I2S_DATA_BIT_WIDTH_16BIT,  // not I2S_DATA_BIT_WIDTH_8BIT or (i2s_data_bit_width_t) BITS_PER_SAMPLE
    .slot_bit_width = I2S_SLOT_BIT_WIDTH_AUTO,
    .slot_mode = I2S_SLOT_MODE_MONO,  // or I2S_SLOT_MODE_STEREO
    .slot_mask = I2S_STD_SLOT_RIGHT,  // use 'I2S_STD_SLOT_LEFT' in case L/R pin is connected to GND !
    .ws_width = I2S_DATA_BIT_WIDTH_16BIT,
    .ws_pol = false,
    .bit_shift = true,   // using [.bit_shift = true] similar PHILIPS or PCM format (NOT 'false' as in MSB macro) ! ..
    .msb_right = false,  // .. or [.msb_right = true] to avoid overdriven and distorted signals on I2S microphones
  },
  .gpio_cfg = {
    .mclk = I2S_GPIO_UNUSED,
    .bclk = (gpio_num_t)I2S_SCK,
    .ws = (gpio_num_t)I2S_WS,
    .dout = I2S_GPIO_UNUSED,
    .din = (gpio_num_t)I2S_SD,
    .invert_flags = {
      .mclk_inv = false,
      .bclk_inv = false,
      .ws_inv = false,
    },
  },
};

// [re_handle]: global handle to the RX channel with channel configuration [std_cfg]
i2s_chan_handle_t rx_handle;

// [myWAV_Header]: selfmade WAV Header:
struct WAV_HEADER {
    char riff[4] = { 'R', 'I', 'F', 'F' }; /* "RIFF"                                   */
    long flength = 0; /* file length in bytes                     ==> Calc at end ! */
    char wave[4] = { 'W', 'A', 'V', 'E' }; /* "WAVE"                                   */
    char fmt[4] = { 'f', 'm', 't', ' ' }; /* "fmt "                                   */
    long chunk_size = 16; /* size of FMT chunk in bytes (usually 16)  */
    short format_tag = 1; /* 1=PCM, 257=Mu-Law, 258=A-Law, 259=ADPCM  */
    short num_chans = 1; /* 1=mono, 2=stereo                         */
    long srate = SAMPLE_RATE; /* samples per second, e.g. 44100           */
    long bytes_per_sec = SAMPLE_RATE * (BITS_PER_SAMPLE / 8); /* srate * bytes_per_samp, e.g. 88200       */
    short bytes_per_samp = (BITS_PER_SAMPLE / 8); /* 2=16-bit mono, 4=16-bit stereo (byte 34) */
    short bits_per_samp = BITS_PER_SAMPLE; /* Number of bits per sample, e.g. 16       */
    char dat[4] = { 'd', 'a', 't', 'a' }; /* "data"                                   */
    long dlength = 0; /* data length in bytes (filelength - 44)   ==> Calc at end ! */
} myWAV_Header;

bool flg_is_recording = false; // only internally used

bool flg_I2S_initialized = false; // to avoid any runtime errors in case user forgot to initialize

// ------------------------------------------------------------------------------------------------------------------------------

bool I2S_Record_Init()
{
    // Get the default channel configuration by helper macro (defined in 'i2s_common.h')
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_AUTO, I2S_ROLE_MASTER);

    i2s_new_channel(&chan_cfg, NULL, &rx_handle); // Allocate a new RX channel and get the handle of this channel
    i2s_channel_init_std_mode(rx_handle, &std_cfg); // Initialize the channel
    i2s_channel_enable(rx_handle); // Before reading data, start the RX channel first

    /* Not used:
    i2s_channel_disable(rx_handle);                   // Stopping the channel before deleting it
    i2s_del_channel(rx_handle);                       // delete handle to release the channel resources */

    flg_I2S_initialized = true; // all is initialized, checked in procedure Record_Start()

    return flg_I2S_initialized;
}

// ------------------------------------------------------------------------------------------------------------------------------
bool Record_Start(String audio_filename)
{
    if (!flg_I2S_initialized) // to avoid any runtime error in case user missed to initialize
    {
        Serial.println("ERROR in Record_Start() - I2S not initialized, call 'I2S_Record_Init()' missed");
        return false;
    }

    if (!flg_is_recording) // entering 1st time -> remove old AUDIO file, create new file with WAV header
    {
        flg_is_recording = true;

        if (SD.exists(audio_filename)) {
            SD.remove(audio_filename);
            DebugPrintln("\n> Existing AUDIO file removed.");
        } else {
            DebugPrintln("\n> No AUDIO file found");
        }

        // Kalo WAV header
        File audio_file = SD.open(audio_filename, FILE_WRITE);
        audio_file.write((uint8_t*)&myWAV_Header, 44);
        audio_file.close();

        DebugPrintln("> WAV Header generated, Audio Recording started ... ");
        return true;
    }

    if (flg_is_recording) // here we land when recording started already -> task: append record buffer to file
    {
        // Array to store Original audio I2S input stream (reading in chunks, e.g. 1024 values)
        int16_t audio_buffer[1024]; // 1024 values [2048 bytes] <- for the original I2S signed 16bit stream
        uint8_t
            audio_buffer_8bit[1024]; // 1024 values [1048 bytes] <- self calculated values in case BITS_PER_SAMPLE == 8

        // now reading the I2S input stream (with NEW <I2S_std.h>)
        size_t bytes_read = 0;
        i2s_channel_read(rx_handle, audio_buffer, sizeof(audio_buffer), &bytes_read, portMAX_DELAY);

        // Optionally: Boostering the very low I2S Microphone INMP44 amplitude (multiplying values with factor
        // GAIN_BOOSTER_I2S)
        if (GAIN_BOOSTER_I2S > 1 && GAIN_BOOSTER_I2S <= 64)
            ; // check your own best values, recommended range: 1-64
        for (int16_t i = 0; i < (bytes_read / 2); ++i) // all 1024 values, 16bit (bytes_read/2)
        {
            audio_buffer[i] = audio_buffer[i] * GAIN_BOOSTER_I2S;
        }

        // If 8bit requested: Calculate 8bit Mono files (self made because any I2S _8BIT settings in I2S would still
        // waste 16bits) use case: reduce resolution 16->8bit to archive smallest .wav size (e.g. for sending to
        // SpeechToText services) details WAV 8bit:
        // https://stackoverflow.com/questions/44415863/what-is-the-byte-format-of-an-8-bit-monaural-wav-file details
        // Convert:  https://stackoverflow.com/questions/5717447/convert-16-bit-pcm-to-8-bit 16-bit signed to 8-bit WAV
        // conversion rule: FROM -32768...0(silence)...+32767 -> TO: 0...128(silence)...256

        if (BITS_PER_SAMPLE == 8) // in case we store a 8bit WAV file we fill the 2nd array with converted values
        {
            for (int16_t i = 0; i < (bytes_read / 2); ++i) {
                audio_buffer_8bit[i] = (uint8_t)(((audio_buffer[i] + 32768) >> 8) & 0xFF);
            }
        }

        /* // Optional (to visualize and validate I2S Microphone INMP44 stream): displaying first 16 samples of each
        chunk DebugPrint("> I2S Rx Samples [Original, 16bit signed]:    "); for (int i=0; i<16; i++) { DebugPrint(
        (String) (int) audio_buffer[i] + "\t"); } DebugPrintln(); if (BITS_PER_SAMPLE == 8) {   DebugPrint("> I2S Rx
        Samples [Converted, 8bit unsigned]:  "); for (int i=0; i<16; i++) { DebugPrint( (String) (int)
        audio_buffer_8bit[i] + "\t"); } DebugPrintln("\n");
        } */

        // Save audio data to SD card (appending chunk array to file end)
        File audio_file = SD.open(audio_filename, FILE_APPEND);
        if (audio_file) {
            if (BITS_PER_SAMPLE == 16) // 16 bit default: appending original I2S chunks (e.g. 1014 values, 2048 bytes)
            {
                audio_file.write((uint8_t*)audio_buffer, bytes_read);
            }
            if (BITS_PER_SAMPLE == 8) // 8bit mode: appending calculated 1014 values instead (1024 bytes, 2048/2)
            {
                audio_file.write((uint8_t*)audio_buffer_8bit, bytes_read / 2);
            }
            audio_file.close();
            return true;
        }

        if (!audio_file) {
            Serial.println("ERROR in Record_Start() - Failed to open audio file!");
            return false;
        }
    }
}

// ------------------------------------------------------------------------------------------------------------------------------
bool Record_Available(String audio_filename, float* audiolength_sec)
{
    // Do nothing to in case no Record was started, recap: 'false' means: 'nothing is stopped' -> no action at all
    // important because typically 'Record_Stop()' is called always in main loop()
    if (!flg_is_recording) {
        return false;
    }

    if (!flg_I2S_initialized) // to avoid runtime errors: do nothing in case user missed to initialize at all
    {
        return false;
    }

    // here we land when Recording is active .. task: stop recording, finalize WAV file, return true/done to main loop()
    if (flg_is_recording) {
        // Update leading WAV haeder - do NOT use 'FILE_WRITE' we need a 'r+'); see here:
        // https://github.com/espressif/arduino-esp32/issues/4028
        // https://cplusplus.com/reference/cstdio/fopen/

        File audio_file = SD.open(audio_filename, "r+");
        long filesize = audio_file.size();
        audio_file.seek(0);
        myWAV_Header.flength = filesize;
        myWAV_Header.dlength = (filesize - 8);
        audio_file.write((uint8_t*)&myWAV_Header, 44);
        audio_file.close();

        flg_is_recording = false; // important: this is done only here

        *audiolength_sec
            = (float)(filesize - 44) / (SAMPLE_RATE * BITS_PER_SAMPLE / 8); // return Audio length (via reference)

        DebugPrintln("> ... Done. Audio Recording finished.");
        DebugPrint("> New AUDIO file: '" + audio_filename + "', filesize [bytes]: " + (String)filesize);
        DebugPrintln(", length [sec]: " + (String)*audiolength_sec);

        return true;
    }
}

#include <WiFiClientSecure.h> // only here needed
/* #include <SD.h>              // library also needed, but already included in main.ino: */

// --- defines & macros --------
int cntt = 0;
#ifndef DEBUG // user can define favorite behaviour ('true' displays addition info)
#define DEBUG true // <- define your preference here
#define DebugPrint(x)                                                                                                  \
    ;                                                                                                                  \
    if (DEBUG) {                                                                                                       \
        Serial.print(x);                                                                                               \
    } /* do not touch */
#define DebugPrintln(x)                                                                                                \
    ;                                                                                                                  \
    if (DEBUG) {                                                                                                       \
        Serial.println(x);                                                                                             \
    } /* do not touch */
#endif

// --- PRIVATE credentials & user favorites -----

const char* deepgramApiKey = "fe167286237d6046d3937fccf733f6eea5b6ace6"; // ## INSERT your Deepgram credentials !

#define STT_LANGUAGE                                                                                                   \
    "en-IN" // forcing single language: e.g. "de" (German), reason: improving recognition quality \
                              // keep EMPTY ("") if you want Deepgram to detect & understand 'your' language automatically, \
                              // language abbreviation examples: "en", "en-US", "en-IN", "de" etc. \
                              // all see here: https://developers.deepgram.com/docs/models-languages-overview

#define TIMEOUT_DEEPGRAM 12 // define your preferred max. waiting time [sec] for Deepgram transcription response

#define STT_KEYWORDS                                                                                                   \
    "&keywords=Kathir&keywords=Aishu&keywords=Amrutha&keywords=Hello&keywords=How are you &keywords=Where are you " // optional, forcing STT to listen exactly
/*#define STT_KEYWORDS          "&keywords=KALO&keywords=Sachin&keywords=Google"
 * exactly */

// --- global vars -------------
WiFiClientSecure client;

// ----------------------------------------------------------------------------------------------------------------------------

String SpeechToText_Deepgram(String audio_filename)
{
    uint32_t t_start = millis();

    // ---------- Connect to Deepgram Server (only if needed, e.g. on INIT and after lost connection)

    if (!client.connected()) {
        DebugPrintln("> Initialize Deepgram Server connection ... ");
        client.setInsecure();
        /* no effect: client.setConnectionTimeout(4000); */
        if (!client.connect("api.deepgram.com", 443)) {
            Serial.println("\nERROR - WifiClientSecure connection to Deepgram Server failed!");
            client.stop(); /* might not have any effect, similar with client.clear() */
            return (""); // in rare cases: WiFiClientSecure freezes (library issue?)
        }
        DebugPrintln("Done. Connected to Deepgram Server.");
    }
    uint32_t t_connected = millis();

    // ---------- Check if AUDIO file exists, check file size

    File audioFile = SD.open(audio_filename);
    if (!audioFile) {
        Serial.println("ERROR - Failed to open file for reading");
        return ("");
    }
    size_t audio_size = audioFile.size();
    audioFile.close();
    DebugPrintln("> Audio File [" + audio_filename + "] found, size: " + (String)audio_size);

    // ---------- flush (remove) potential inbound streaming data before we start with any new user request
    // reason: increasing reliability, also needed in case we have pending data from earlier Deepgram_KeepAlive()

    String socketcontent = "";
    while (client.available()) {
        char c = client.read();
        socketcontent += String(c);
    }
    int RX_flush_len = socketcontent.length();

    // ---------- Sending HTTPS request header to Deepgram Server

    String optional_param; // see: https://developers.deepgram.com/docs/stt-streaming-feature-overview
    optional_param = "?model=nova-2-general"; // Deepgram recommended model (high readability, lowest word error rates)
    optional_param
        += (STT_LANGUAGE != "") ? ("&language=" + (String)STT_LANGUAGE) : ("&detect_language=true"); // see #defines
    optional_param += "&smart_format=true"; // applies formatting (Punctuation, Paragraphs, upper/lower etc ..)
    optional_param += "&numerals=true"; // converts numbers from written to numerical format (works with 'en' only)
    optional_param += STT_KEYWORDS; // optionally too: keyword boosting on multiple custom vocabulary words

    client.println("POST /v1/listen" + optional_param + " HTTP/1.1");
    client.println("Host: api.deepgram.com");
    client.println("Authorization: Token " + String(deepgramApiKey));
    client.println("Content-Type: audio/wav");
    client.println("Content-Length: " + String(audio_size));
    client.println(); // header complete, now sending binary body (wav bytes) ..

    DebugPrintln("> POST Request to Deepgram Server started, sending WAV data now ...");
    uint32_t t_headersent = millis();

    // ---------- Reading the AUDIO wav file, sending in CHUNKS (closing file after done)
    // idea found here (WiFiClientSecure.h issue): https://www.esp32.com/viewtopic.php?t=4675

    File file = SD.open(audio_filename, FILE_READ);
    const size_t bufferSize = 1024; // best values seem anywhere between 1024 and 2048;
    uint8_t buffer[bufferSize];
    size_t bytesRead;
    while (file.available()) {
        bytesRead = file.read(buffer, sizeof(buffer));
        if (bytesRead > 0) {
            client.write(buffer, bytesRead);
        } // sending WAV AUDIO data
    }
    file.close();
    DebugPrintln("> All bytes sent, waiting Deepgram transcription");
    uint32_t t_wavbodysent = millis();

    // ---------- Waiting (!) to Deepgram Server response (stop waiting latest after TIMEOUT_DEEPGRAM [secs])

    String response = ""; // waiting until available() true and all data completely received
    while (response == "" && millis() < (t_wavbodysent + TIMEOUT_DEEPGRAM * 1000)) {
        while (client.available()) {
            char c = client.read();
            response += String(c);
        }
        // printing dots '.' each 100ms while waiting response
        DebugPrint(".");
        delay(100);
    }
    DebugPrintln();
    if (millis() >= (t_wavbodysent + TIMEOUT_DEEPGRAM * 1000)) {
        Serial.print("\n*** TIMEOUT ERROR - forced TIMEOUT after " + (String)TIMEOUT_DEEPGRAM + " seconds");
        Serial.println(" (is your Deepgram API Key valid ?) ***\n");
    }
    uint32_t t_response = millis();

    // ---------- closing connection to Deepgram
    client
        .stop(); // observation: unfortunately needed, otherwise the 'audio_play.openai_speech() in AUDIO.H not working
                 // ! so we close for now, but will be opened again on next call (and regularly in Deepgram_KeepAlive())

    // ---------- Parsing json response, extracting transcription etc.

    int response_len = response.length();
    String transcription = json_object(response, "\"transcript\":");
    String language = json_object(response, "\"detected_language\":");
    String wavduration = json_object(response, "\"duration\":");

    DebugPrintln("---------------------------------------------------");
    /* DebugPrintln( "-> Total Response: \n" + response + "\n");  // ### uncomment to see the complete server response
     */
    DebugPrintln("-> Latency Server (Re)CONNECT [t_connected]:   " + (String)((float)((t_connected - t_start)) / 1000));
    ;
    DebugPrintln(
        "-> Latency sending HEADER [t_headersent]:      " + (String)((float)((t_headersent - t_connected)) / 1000));
    DebugPrintln(
        "-> Latency sending WAV file [t_wavbodysent]:   " + (String)((float)((t_wavbodysent - t_headersent)) / 1000));
    DebugPrintln(
        "-> Latency DEEPGRAM response [t_response]:     " + (String)((float)((t_response - t_wavbodysent)) / 1000));
    DebugPrintln("=> TOTAL Duration [sec]: ..................... " + (String)((float)((t_response - t_start)) / 1000));
    DebugPrintln("=> RX data prior request [bytes]: " + (String)RX_flush_len);
    DebugPrintln("=> Server detected audio length [sec]: " + wavduration);
    DebugPrintln("=> Server response length [bytes]: " + (String)response_len);
    DebugPrintln("=> Detected language (optional): [" + language + "]");
    DebugPrintln("=> Transcription: [" + transcription + "]");
    DebugPrintln("---------------------------------------------------\n");

    // ---------- return transcription String
    return transcription;
}

// ----------------------------------------------------------------------------------------------------------------------------

void Deepgram_KeepAlive() // should be called each 5 seconds about (to overcome the default autoclosing after 10 secs)
{
    uint32_t t_start = millis();
    DebugPrint("* Deepgram KeepAlive | ");

    // ---------- Connect to Deepgram Server (on INIT and every time in case closed)

    if (!client.connected()) {
        DebugPrint("NEW Reconnection ... ");
        client.setInsecure();
        /* no effect: client.setConnectionTimeout(4000); */
        if (!client.connect("api.deepgram.com", 443)) {
            Serial.println("\n* PING Error - Server Connection failed.");
            /* no effect: client.clear(); client.stop(); */
            return; // in rare cases: WiFiClientSecure freezes (library issue?)
        }
        DebugPrint("Done, connected.  -->  Connect Latency [sec]: ");
        DebugPrintln((String)((float)((millis() - t_start)) / 1000));
        return; // done, on next cycle (after e.g. 5 secs) we ping data
    }

    // ---------- TX - Sending DATA to Deepgram Server .....
    /* Deepgram does support a dedicated KeepAlive feature, but unfortunately not for pre-recorded audio
    // for streaming we could use this snippet:
    String payload = "{\"type\": \"KeepAlive\"}";
    client.println("POST /v1/listen HTTP/1.1");
    client.println("Host: api.deepgram.com");
    client.println("Authorization: Token " + String(deepgramApiKey));
    client.println("Content-Type: application/json; charset=utf-8");
    client.println("Content-Length: " + payload.length());
    client.println();
    client.println( payload );
    // so for 'pre-recorded audio' we use our own workflow below: ... */

    // sending a dummy 16Khz/8bit audio wav with header (20 values only, 0x80 for silence)
    // [0x40,0x00,0x00,0x00] = filesize 64 bytes,  [0x14,0x00,0x00,0x00] = 20 wav values (~ 1 millisec audio only)

    uint8_t empty_wav[] = { 0x52, 0x49, 0x46, 0x46, 0x40, 0x00, 0x00, 0x00, 0x57, 0x41, 0x56, 0x45, 0x66, 0x6D, 0x74,
        0x20, 0x10, 0x00, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x80, 0x3E, 0x00, 0x00, 0x80, 0x3E, 0x00, 0x00, 0x01,
        0x00, 0x08, 0x00, 0x64, 0x61, 0x74, 0x61, 0x14, 0x00, 0x00, 0x00, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80,
        0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80 };

    client.println("POST /v1/listen HTTP/1.1");
    client.println("Host: api.deepgram.com");
    client.println("Authorization: Token " + String(deepgramApiKey));
    client.println("Content-Type: audio/wav");
    client.println("Content-Length: " + String(sizeof(empty_wav)));
    client.println(); // header complete, now sending wav bytes ..
    client.write(empty_wav, sizeof(empty_wav));

    // ---------- RX - Receiving DATA from Deepgram Server ....
    // keep in mind: we do NOT want to wait until 'related' answer received ('available()' needs about ~1sec to become
    // TRUE) means: typically we read the data from earlier TX ;) .. doesn't matter as long we flush before final user
    // request :)

    String response = "";
    while (client.available()) {
        char c = client.read();
        response += String(c);
    }
    int RX_len = response.length();

    // ---------- NOT closing Deepgram connection
    // keep in minsd: we do NOT close connection, so audio_play.openai_speech() in AUDIO.H won't work (library issue)
    // connection will be closed in SpeechToText_Deepgram(), allowing to play audio after user voice transcription done
    /* client.stop(); */

    // ---------- Debugging Info
    DebugPrint("TX (WAV): " + (String)sizeof(empty_wav) + " bytes | ");
    DebugPrint("RX (TXT): " + (String)RX_len + " bytes  -->  ");
    DebugPrintln("Total Latency [sec]: " + (String)((float)((millis() - t_start)) / 1000));
}

// ----------------------------------------------------------------------------------------------------------------------------
// JSON String Extract: Searching [element] in [input], example: element = "transcript": -> returns content 'How are
// you?'

String json_object(String input, String element)
{
    String content = "";
    int pos_start = input.indexOf(element);
    if (pos_start > 0) // if element found:
    {
        pos_start += element.length(); // pos_start points now to begin of element content
        int pos_end = input.indexOf(",\"", pos_start); // pos_end points to ," (start of next element)
        if (pos_end > pos_start) // memo: "garden".substring(from3,to4) is 1 char "d" ..
        {
            content = input.substring(pos_start, pos_end); // .. thats why we use for 'to' the pos_end (on ," ):
        }
        content.trim(); // remove optional spaces between the json objects
        if (content.startsWith("\"")) // String objects typically start & end with quotation marks "
        {
            content = content.substring(1, content.length() - 1); // remove both existing quotation marks (if exist)
        }
    }
    return (content);
}

bool I2S_Record_Init();
bool Record_Start(String filename);
bool Record_Available(String filename, float* audiolength_sec);
String SpeechToText_Deepgram(String filename);
void Deepgram_KeepAlive();

// ------------------------------------------------------------------------------------------------------------------------------
void setup()
{
    // Initialize serial communication
    Serial.begin(115200);
    ble_soft.begin(9600, SERIAL_8N1, RX_PIN, TX_PIN); // Serial2 at 115200 baud
    pinMode(vib_mot, OUTPUT);
    digitalWrite(vib_mot, LOW);
    // Pin assignments:
    pinMode(LED, OUTPUT);
    pinMode(pin_RECORD_BTN, INPUT_PULLUP); // use INPUT_PULLUP if no external Pull-Up connected ##

    if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
        Serial.println(F("SSD1306 allocation failed"));
        for (;;)
            ; // Don't proceed, loop forever
    }

    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    display.display();
    delay(2000);

    display.clearDisplay();
    display.setTextSize(1);

    display.clearDisplay();
    display.setTextSize(2);
    display.setCursor(25, 0);
    display.print(F("SH-AID"));
    display.setTextSize(1);
    display.setCursor(0, 13);
    display.print(F("---------------------"));

    display.display();

    // // Connecting to WLAN
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, password);
    while (WiFi.status() != WL_CONNECTED) {
        Serial.print(".");
        delay(500);
    }
    // Initialize SD card
    if (!SD.begin()) {
        Serial.println("ERROR - SD Card initialization failed!");
        return;
    }

    I2S_Record_Init();

    // INIT done, starting user interaction
    Serial.println("> HOLD button for recording AUDIO .. RELEASE button for REPLAY & Deepgram transcription");
}

// ------------------------------------------------------------------------------------------------------------------------------
void loop()
{
    digitalWrite(vib_mot, LOW);
    delay(50);

    if (WiFi.status() == WL_CONNECTED) {
        // Display Connected
        display.clearDisplay();
        display.setTextSize(2);
        display.setCursor(25, 0);
        display.print(F("SH-AID"));
        display.setTextSize(1);
        display.setCursor(0, 13);
        display.print(F("---------------------"));
        display.setCursor(0, 20);
        display.print(F("Connected"));

        // wifi_status = 1;

    } else {
        // Display Not Connected
        // wifi_status = 0;
        display.clearDisplay();
        display.setTextSize(2);
        display.setCursor(25, 0);
        display.print(F("SH-AID"));
        display.setTextSize(1);
        display.setCursor(0, 13);
        display.print(F("---------------------"));
        display.setCursor(0, 20);
        display.print(F("Not Connected"));
        display.display();

        Serial.println("Reconnecting to WiFi...");
    }

    if (digitalRead(pin_RECORD_BTN) == LOW) // Recording started (ongoing)
    {

        digitalWrite(LED, HIGH);

        delay(30); // unbouncing & suppressing button 'click' noise in begin of audio recording

        // Start Recording
        Record_Start(AUDIO_FILE);

        // Display Recording In Progress
        // display.clearDisplay();
        // display.setTextSize(2);
        // display.setCursor(25, 0);
        // display.print(F("SH-AID"));
        // display.setTextSize(1);
        // display.setCursor(0, 13);
        // display.print(F("---------------------"));
        display.setCursor(0, 30);
        display.print(F("Recording..."));
        display.display();

    } else if (digitalRead(pin_RECORD_BTN) == HIGH) // Recording not started yet .. OR stopped now (on release button)
    {

        digitalWrite(LED, LOW);

        float recorded_seconds;

        if (Record_Available(AUDIO_FILE, &recorded_seconds)) // true once when recording finalized (.wav file available)
        {

            if (recorded_seconds > 0.4) // ignore short btn TOUCH (e.g. <0.4 secs, used for 'audio_play.stopSong' only)
            {

                // [SpeechToText] - Transcript the Audio (waiting here until done)

                digitalWrite(LED, HIGH);

                String transcription = SpeechToText_Deepgram(AUDIO_FILE);

                digitalWrite(LED, LOW);

                Serial.println(transcription);

                // Display Transcription Result
                // display.clearDisplay();
                // display.setTextSize(2);
                // display.setCursor(25, 0);
                // display.print(F("SH-AID"));
                // display.setTextSize(1);
                // display.setCursor(0, 13);
                // display.print(F("---------------------"));
                display.setCursor(0, 30);
                display.print(F("Result "));
                display.print(transcription);

                Serial.println(transcription.length());
                if (transcription.length() <= 1) {
                    digitalWrite(LED, HIGH);

                    String transcription = SpeechToText_Deepgram(AUDIO_FILE);

                    digitalWrite(LED, LOW);

                    Serial.println(transcription);
                    display.setCursor(0, 30);
                    display.print(F("Result "));
                    display.print(transcription);
                }
                display.display();

            } else {

                // Display Short Recording Message
                // display.clearDisplay();
                // display.setTextSize(2);
                // display.setCursor(25, 0);
                // display.print(F("SH-AID"));
                // display.setTextSize(1);
                // display.setCursor(0, 13);
                // display.print(F("---------------------"));
                display.setCursor(0, 30);
                display.print(F("Short Recording"));
                display.display();
            }
        }
    }

    // [Optional]: Stabilize WiFiClientSecure.h + Improve Speed of STT Deepgram response (~1 sec faster)
    if (digitalRead(pin_RECORD_BTN) == HIGH && !audio_play.isRunning()) // but don't do it during recording or playing
    {

        static uint32_t millis_ping_before;

        if (millis() > (millis_ping_before + 15000)) {

            millis_ping_before = millis();

            digitalWrite(LED, HIGH);

            Deepgram_KeepAlive();
        }

        String incomingChar = "";
        while (Serial.available()) {
            char k = Serial.read();
            incomingChar += k;

            delay(10);
        }
        if (incomingChar.length() > 0) {
            Serial.println(incomingChar);
            String data1 = getSplitValue(incomingChar, ',', 0);
            String data2 = getSplitValue(incomingChar, ',', 1);
            String data3 = getSplitValue(incomingChar, ',', 2);
            String data4 = getSplitValue(incomingChar, ',', 3);

            float data1acc = getSplitValue(data1, ':', 1).toFloat();
            float data2acc = getSplitValue(data2, ':', 1).toFloat();
            float data3acc = getSplitValue(data3, ':', 1).toFloat();
            float data4acc = getSplitValue(data4, ':', 1).toFloat();

            String data1name = getSplitValue(data1, ':', 0);
            String data2name = getSplitValue(data2, ':', 0);
            String data3name = getSplitValue(data3, ':', 0);
            String data4name = getSplitValue(data4, ':', 0);

            Serial.print("Data1: ");
            Serial.print(data1name);
            Serial.print(" ");
            Serial.println(data1acc);
            Serial.print("Data2: ");
            Serial.print(data2name);
            Serial.print(" ");
            Serial.println(data2acc);
            Serial.print("Data3: ");
            Serial.print(data3name);
            Serial.print(" ");
            Serial.println(data3acc);
            Serial.print("Data4: ");
            Serial.print(data4name);
            Serial.print(" ");
            Serial.println(data4acc);

            // Finding the maximum accuracy
            float maxAcc = 0.89;
            String maxName = data1name;

            // Compare and find the maximum
            if (data2acc > maxAcc) {
                maxAcc = data2acc;
                maxName = data2name;
            }
            if (data3acc > maxAcc) {
                maxAcc = data3acc;
                maxName = data3name;
            }
            if (data4acc > maxAcc) {
                maxAcc = data4acc;
                maxName = data4name;
            }

            Serial.print("Maximum Accuracy: ");
            Serial.print(maxName);
            Serial.print(" with a value of ");
            Serial.println(maxAcc);

            if (maxName == "aishu" || maxName == "amrutha") {
                cntt++;
                if (cntt >= 2) {
                    digitalWrite(vib_mot, HIGH);
                    display.clearDisplay();
                    display.setTextSize(2);
                    display.setCursor(25, 0);
                    display.print(F("SH-AID"));
                    display.setTextSize(1);
                    display.setCursor(0, 13);
                    display.print(F("---------------------"));
                    display.setCursor(0, 20);
                    // Convert maxName to uppercase
                    String upperMaxName = maxName; // Create a copy of maxName
                    upperMaxName.toUpperCase(); // Convert to uppercase

                    // Now display the uppercase name
                    display.println(upperMaxName);
                    display.println(F("Someone is Calling You"));
                    display.print(F(" "));
                    display.print(maxAcc);
                    display.display();
                    delay(50);
                    delay(50);
                    digitalWrite(vib_mot, LOW);
                    cntt = 0;
                }

            } else if (maxName == "horn") {
                digitalWrite(vib_mot, HIGH);
                display.clearDisplay();
                display.setTextSize(2);
                display.setCursor(25, 0);
                display.print(F("SH-AID"));
                display.setTextSize(1);
                display.setCursor(0, 13);
                display.print(F("---------------------"));
                display.setCursor(0, 20);
                display.println("Horn Sound Detected \nPlease be careful on the road");

                display.print(F(" "));
                display.display();
                delay(500);
                digitalWrite(vib_mot, LOW);
                display.clearDisplay();
            } else {
                digitalWrite(vib_mot, LOW);
                cntt = 0;
            }
        }

        if (ble_soft.available()) {
            char incomingChar = ble_soft.read();
            Serial.println(incomingChar);
            if (incomingChar == '1') {
                digitalWrite(vib_mot, HIGH);
                display.clearDisplay();
                display.setTextSize(2);
                display.setCursor(25, 0);
                display.print(F("SH-AID"));
                display.setTextSize(1);
                display.setCursor(0, 13);
                display.print(F("---------------------"));
                display.setCursor(0, 20);
                display.print(F("Someone is Trying to Break the Door"));
                display.display();
                digitalWrite(vib_mot, LOW);
                delay(50);
                digitalWrite(vib_mot, HIGH);
                delay(50);
                digitalWrite(vib_mot, LOW);
                delay(50);
                digitalWrite(vib_mot, HIGH);
                delay(50);
                digitalWrite(vib_mot, LOW);
                delay(50);
                digitalWrite(vib_mot, HIGH);
                delay(50);
            }
            if (incomingChar == '2') {
                display.clearDisplay();
                display.setTextSize(2);
                display.setCursor(25, 0);
                display.print(F("SH-AID"));
                display.setTextSize(1);
                display.setCursor(0, 13);
                display.print(F("---------------------"));
                display.setCursor(0, 20);
                display.print(F("Someone is waiting for you at the Door"));
                display.display();
                digitalWrite(vib_mot, HIGH);
                delay(50);
            }
        }

        Serial.flush();
    }
}

String getSplitValue(String data, char separator, int index)
{
    int found = 0;
    int strIndex[] = { 0, -1 };
    int maxIndex = data.length() - 1;
    for (int i = 0; i <= maxIndex && found <= index; i++) {
        if (data.charAt(i) == separator || i == maxIndex) {
            found++;
            strIndex[0] = strIndex[1] + 1;
            strIndex[1] = (i == maxIndex) ? i + 1 : i;
        }
    }
    return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}
